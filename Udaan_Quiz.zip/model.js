class Course{
    constructor(code,name){
        this.code = code;
        this.name = name;
        this.quizzes = []
        this.users = []
    }

    addQuiz(quiz){
        this.quizzes.push(quiz)
    }

    enrollUser(user){
        this.users.append(user)
    }

    getallQuizes(){
        return this.quizzes;
    }

}

class Quiz{
    constructor(name){
        this.name = name;
        this.questions = []
    }
    addQuestion(question){
        this.questions.push(question)
    }
    getScore(answers){
        marks = 0
        answers.forEach(function(index,ans){
            if(ans==questions[index].getAns()){
                marks = marks + 1;
            }
        })
    }
}

class Question{
    constructor(quesText,options,ans){
        this.quizName = quizName;
        this.quesText = quesText;
        this.options = options;
        this.ans = ans;
    }
    getAns(){
        return this.ans;
    }
}

class Attempt{
    constructor(uname,quizName,score){
        this.uname = uname;
        this.quizName = quizName;
        this.score = score;
    }
    getQuizName(){
    	return this.quizName;
    }
    getScore(){
    	return this.score;
    }
}

class User{
    constructor(uname){
        this.uname = uname;
        this.attempts = [];
        this.courses = [];
    }
    addAttempt(attempt){
        this.attempts.push(attempt)
    }
    addCourse(course){
        this.courses.push(course)
    }
    getAttempts(){
        return this.attempts
    }
}