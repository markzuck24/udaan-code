



function login(){
    var uname = $("#uname").val()

    if(uname != null && getUser(uname)==null){
        addNewUser(uname)
    }
    var allCourses = getAllCourses(uname)
    console.log(allCourses)
    var enrolledCourseCodes = getEnrolledCoursesCodefor(uname)
    print(enrolledCourseCodes)
    displayCoursePage(uname,allCourses,enrolledCourseCodes)
}

function enrollCourse(code){
    console.log(code)
}


function displayCoursePage(uname,courses,enrolled){
    $(".login").hide()
    $('#cuname').html(uname)
    courses.forEach(function(course){
        if(enrolled.has(course.code)){
            $(".list_enrolled").append("<div>Hello enrolled</div>")
        }else{
            //append new element
            $(".list_unenrolled").append(unenrolledCourseTemplate(course))
            //set enroll on click
            $('#'+course.code+'enroll').click(function(){
                enrollCourse(course.code);
            })
        }
    })
}


function displayQuizzes(){
    $(".login").hide()
    $(".courses").hide()
    var uname = $("#uname").val()

    if(uname != null && getUser(uname)==null){
        addNewUser(uname)
    }
    var allCourses = getAllCourses(uname)
    
}


// login()