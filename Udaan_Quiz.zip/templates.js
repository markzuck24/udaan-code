function unenrolledCourseTemplate(course){
    var template = 
    '<div class="row" id="'+course.code+'">'+
        '<h4 class="col">'+course.name+'</h4>'+
        '<div id="'+course.code+'enroll" class="col btn btn-primary">Enroll</div>'+
    '</div>'
    return template
}

function questionTemplate(question){
	var i;
	var template = '<div class="question"><h5>' + question.quesText +
		'</h5><div class="options">' + 
		for(i = 0 ; i < question.options.length ; i++){
		 '<div class="option"><input type="radio" value="0">'+  question.options[i] + '</div>' +
		}
        '</div>'+
        '</div>'
        return template
}