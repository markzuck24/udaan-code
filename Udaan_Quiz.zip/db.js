var users=[];
var courses=[];

function print(content){
    console.log(content)
}

function initDB(){
    addNewUser("test")
    addNewCourse("CS744","Operating Systems")
    addNewCourse("CS742","Networks")
    addNewCourse("CS747","Formal Verification")
    addNewCourse("CS755","NLP")
    addNewCourse("CS725","FML")
}


function addNewUser(uname){
    var user = new User(uname)
    users.push(user)
}
function addNewCourse(code,name){
    var course = new Course(code,name)
    courses.push(course)
}

function getUser(uname){
    users.forEach(function(user){
        if(uname==user.uname){
            return user
        }
    })
    return null
}

function getCourseWith(code){
    courses.forEach(function(course){
        if(course.code == code){
            return course;
        }
    })
}

function getAllCourses(){
    return courses;
}

function getQuizes(uname, course){
    var quizes = course.getallQuizes();
    var user = getUser(uname);
    var attempt = user.getAttempts();

    console.log(quizes);
    console.log(user);
    console.log(attempt);
}

function getScore(uname, quizName){
    var user = getUser(uname);
    var attempt = user.getAttempt();
    attempt.forEach(function(index,ans){
            if(quizName==questions[index].getQuizName()){
                return questions[index].getScore();
            }
        })
    return null;
}


function getEnrolledCoursesCodefor(uname){
    var enrolled = new Set()
    var user = getUser(uname)
    if(user != null){
        user.courses.forEach(function(course){
            enrolled.add(course.code)
        })
    }
    return enrolled
}

initDB()